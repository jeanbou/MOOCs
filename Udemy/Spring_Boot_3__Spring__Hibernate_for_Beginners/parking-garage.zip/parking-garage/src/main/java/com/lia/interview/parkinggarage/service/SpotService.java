package com.lia.interview.parkinggarage.service;
import java.util.List;

import com.lia.interview.parkinggarage.model.Spot;

public interface SpotService {

    Spot create(Spot spot);

    Spot update(Spot spot);

    void delete(Long id);

    List<Spot> findAll();

    Spot findSpotById(Long id);

    Spot findByNumber(String number);
}
