package com.lia.interview.parkinggarage.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class SpotDTO {

    @NotNull
    @Min(value=5)
    private String number;
    private String size;  // how to annotate here?
    private String spotName;
    private Long spotId;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getSpotName() {
        return spotName;
    }

    public void setGarageName(String garageName) {
        this.spotName = garageName;
    }

    public Long getGarageId() {
        return spotId;
    }

    public void setGarageId(Long garageId) {
        this.spotId = garageId;
    }
}
