package com.lia.interview.parkinggarage.repository;
import java.util.List;
import java.util.Optional;

import com.lia.interview.parkinggarage.model.Garage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GarageRepository extends JpaRepository<Garage, Long> {
//    Garage findGarageById(Long id);
    Optional<Garage> findGarageByName(String name);
//    List<Garage> findAll();
}
