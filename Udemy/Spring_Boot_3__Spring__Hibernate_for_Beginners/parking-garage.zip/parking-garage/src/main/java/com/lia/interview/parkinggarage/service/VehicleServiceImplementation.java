package com.lia.interview.parkinggarage.service;

public class VehicleServiceImplementation {
}
