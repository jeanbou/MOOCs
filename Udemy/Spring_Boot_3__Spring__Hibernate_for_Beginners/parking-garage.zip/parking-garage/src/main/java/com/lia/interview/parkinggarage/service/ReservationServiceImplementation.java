package com.lia.interview.parkinggarage.service;

import com.lia.interview.parkinggarage.model.Reservation;
import com.lia.interview.parkinggarage.repository.ReservationRepository;

import java.util.List;

public class ReservationServiceImplementation implements ReservationService {

    private final ReservationRepository reservationRepository;

    public ReservationServiceImplementation(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    @Override
    public Reservation create(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    @Override
    public Reservation update(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    @Override
    public void delete(Long id) {
        reservationRepository.deleteById(id);
    }

    @Override
    public List<Reservation> findAll() {
        return reservationRepository.findAll();
    }

    @Override
    public Reservation findReservationById(Long id) {
        return reservationRepository.findReservationById(id);
    }

}
