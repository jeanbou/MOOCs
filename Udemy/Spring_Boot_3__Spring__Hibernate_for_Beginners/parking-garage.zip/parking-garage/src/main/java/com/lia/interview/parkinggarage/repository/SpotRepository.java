package com.lia.interview.parkinggarage.repository;
import java.util.List;
import java.util.Optional;

import com.lia.interview.parkinggarage.model.Spot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpotRepository extends JpaRepository<Spot, Long> {
//    Spot findSpotById(Long id);
    Optional<Spot> findSpotByNumber(String number);
    List<Spot> findSpotByGarageId(Long garageId);
    List<Spot> findSpotByGarageName(Long garageName);
    List<Spot> findSpotBySize(String size);

}
