package com.lia.interview.parkinggarage.service;

import com.lia.interview.parkinggarage.model.Garage;
import com.lia.interview.parkinggarage.repository.GarageRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GarageServiceImplementation implements GarageService {

    private final GarageRepository garageRepository;

    public GarageServiceImplementation(GarageRepository garageRepository) {
        this.garageRepository = garageRepository;
    }

    @Override
    public Garage create(Garage garage) {
        return garageRepository.save(garage);
    }

    @Override
    public Garage update(Garage garage) {
        return garageRepository.save(garage);
    }

    @Override
    public void delete(Long id) {
        garageRepository.deleteById(id);
    }

    @Override
    public List<Garage> findAll() {
        return garageRepository.findAll();
    }

    @Override
    public Garage findGarageById(Long id) {
        Optional<Garage> garage = garageRepository.findById(id);
        if(garage.isPresent())
            return garage.get();
        throw new RuntimeException("There is no garage with the given id: " + id);
    }

    @Override
    public Garage findByName(String name) {
        Optional<Garage> garage = garageRepository.findGarageByName(name);
        if(garage.isPresent())
            return garage.get();
        throw new RuntimeException("There is no garage with the given name: " + name);
    }
}

