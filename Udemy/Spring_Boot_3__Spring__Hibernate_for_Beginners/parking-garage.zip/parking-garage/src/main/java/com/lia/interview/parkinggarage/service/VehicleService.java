package com.lia.interview.parkinggarage.service;

import com.lia.interview.parkinggarage.model.Vehicle;

import java.util.List;

public interface VehicleService {
    Vehicle create(Vehicle vehicle);

    Vehicle update(Vehicle vehicle);

    void delete(Long id);

    List<Vehicle> findAll();

    Vehicle findVehicleById(Long id);

    Vehicle findByPlateNumber(String plateNumber);
}
