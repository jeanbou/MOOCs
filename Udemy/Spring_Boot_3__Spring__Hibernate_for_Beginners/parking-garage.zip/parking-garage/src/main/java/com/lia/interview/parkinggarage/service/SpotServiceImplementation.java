package com.lia.interview.parkinggarage.service;

import com.lia.interview.parkinggarage.model.Garage;
import com.lia.interview.parkinggarage.model.Spot;
import com.lia.interview.parkinggarage.repository.SpotRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public class SpotServiceImplementation implements SpotService{

    private final SpotRepository spotRepository;

    public SpotServiceImplementation(SpotRepository spotRepository) {
        this.spotRepository = spotRepository;
    }

    @Override
    public Spot create(Spot spot) {
        return spotRepository.save(spot);
    }

    @Override
    public Spot update(Spot spot) {
        return spotRepository.save(spot);
    }

    @Override
    public void delete(Long id) {
        spotRepository.deleteById(id);
    }

    @Override
    public List<Spot> findAll() {
        return spotRepository.findAll();
    }

    @Override
    public Spot findSpotById(Long id) {
        Optional<Spot> spot = spotRepository.findById(id);
        if(spot.isPresent())
            return spot.get();
        throw new RuntimeException("There is no spot with the given id: " + id);
    }

    @Override
    public Spot findByNumber(String number) {
        Optional<Spot> spot = spotRepository.findSpotByNumber(number);
        if(spot.isPresent())
            return spot.get();
        throw new RuntimeException("There is no garage with the given number: " + number);
    }
}
