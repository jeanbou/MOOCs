package com.lia.interview.parkinggarage.view;

public class ReservationView {
}
