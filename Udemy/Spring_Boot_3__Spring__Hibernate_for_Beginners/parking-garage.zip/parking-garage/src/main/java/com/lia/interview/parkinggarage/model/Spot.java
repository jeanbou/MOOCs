package com.lia.interview.parkinggarage.model;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity
public class Spot {
    public enum StatusType {
        Small,
        Medium,
        Large
    }


    @Column(name="id")
    private @Id @GeneratedValue Long id;
    @Column(name="number")
    private String number;
    @Column(name="size")
    private String size;
    @Column(name="garage_name")
    private String garageName;

    @Column(name="garage_id")
    private Long garageId;


    public String getGarageName() {
        return garageName;
    }

    public void setGarageName(String garageName) {
        this.garageName = garageName;
    }

    public Long getGarageId() {
        return garageId;
    }

    public void setGarageId(Long garageId) {
        this.garageId = garageId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Spot(String number, String size, String garageName, Long garageId) {
        this.number = number;
        this.size = size;
        this.garageName = garageName;
        this.garageId = garageId;
    }
}
