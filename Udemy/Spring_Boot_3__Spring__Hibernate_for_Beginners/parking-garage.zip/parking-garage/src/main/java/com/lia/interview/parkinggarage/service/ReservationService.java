package com.lia.interview.parkinggarage.service;

import com.lia.interview.parkinggarage.model.Reservation;

import java.util.List;

public interface ReservationService {
    Reservation create(Reservation reservation);

    Reservation update(Reservation reservation);

    void delete(Long id);

    List<Reservation> findAll();

    Reservation findReservationById(Long id);

}
