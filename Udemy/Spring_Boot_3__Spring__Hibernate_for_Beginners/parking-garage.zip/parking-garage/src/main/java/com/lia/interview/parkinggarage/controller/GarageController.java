package com.lia.interview.parkinggarage.controller;
import com.lia.interview.parkinggarage.dto.GarageDTO;
import com.lia.interview.parkinggarage.dto.mapper.GarageDTOMapper;
import com.lia.interview.parkinggarage.model.Garage;
import com.lia.interview.parkinggarage.service.GarageService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value="/garages")
public class GarageController {


    private final GarageService garageService;
    private final GarageDTOMapper garageMapper;

    public GarageController(GarageService garageService, GarageDTOMapper garageMapper) {
        this.garageService = garageService;
        this.garageMapper = garageMapper;
    }

    @PostMapping()
    public ResponseEntity<GarageDTO> createGarage(@RequestBody GarageDTO garageDTO){
        Garage garage = garageMapper.mapGarageDTOToGarage(garageDTO);
        Garage newGarage = garageService.create(garage);
        return ResponseEntity.ok(garageMapper.mapGarageToGarageDTO(newGarage));
    }

    @PutMapping()
    public ResponseEntity<GarageDTO> update(@RequestBody GarageDTO garageDTO){
        Garage garage = garageMapper.mapGarageDTOToGarage(garageDTO);
        Garage newGarage = garageService.update(garage);
        return ResponseEntity.ok(garageMapper.mapGarageToGarageDTO(newGarage));
    }

    @GetMapping("/find/{name}")
    public ResponseEntity<GarageDTO> viewGarageByName(@PathVariable("name") String name){
        Garage newGarage = garageService.findByName(name);
        return ResponseEntity.ok(garageMapper.mapGarageToGarageDTO(newGarage));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> createGarage(@PathVariable("id") Long id){
        garageService.delete(id);
        return ResponseEntity.ok("Garage Deleted");
    }
}

