package com.lia.interview.parkinggarage.controller;

import com.lia.interview.parkinggarage.model.Vehicle;
import com.lia.interview.parkinggarage.repository.VehicleRepository;
import com.lia.interview.parkinggarage.service.VehicleService;

import java.util.List;
import java.util.Optional;

public class VehicleController implements VehicleService {

    private final VehicleRepository vehicleRepository;

    public VehicleController(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }


    @Override
    public Vehicle create(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }

    @Override
    public Vehicle update(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }

    @Override
    public void delete(Long id) {
        vehicleRepository.deleteById(id);
    }

    @Override
    public List<Vehicle> findAll() {
        return vehicleRepository.findAll();
    }

    @Override
    public Vehicle findVehicleById(Long id) {
        Optional<Vehicle> vehicle = vehicleRepository.findById(id);
        if(vehicle.isPresent())
            return vehicle.get();
        throw new RuntimeException("There is no vehicle with the given id: " + id);
    }

    @Override
    public Vehicle findByPlateNumber(String plateNumber) {
        Optional<Vehicle> vehicle = vehicleRepository.findVehicleByPlateNumber(plateNumber);
        if(vehicle.isPresent())
            return vehicle.get();
        throw new RuntimeException("There is no vehicle with the given plate number: " + plateNumber);
    }
}
