package com.lia.interview.parkinggarage.model;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;



@Data
@Entity
public class Reservation {
    public enum StatusType {
        Booked,
        Canceled
    }


    @Column(name="id")
    private @Id @GeneratedValue Long id;

    @Column(name="number")
    private String number;

    @Column(name="start_time")
    private Timestamp startTime;

    @Column(name="end_time")
    private Timestamp endTime;

    @Column(name="paid")
    private Boolean paid;

    @Enumerated(EnumType.STRING)
    @Column(name="status")
    private StatusType status;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public Boolean getPaid() {
        return paid;
    }

    public void setPaid(Boolean paid) {
        this.paid = paid;
    }

    public StatusType getStatus() {
        return status;
    }

    public void setStatus(StatusType status) {
        this.status = status;
    }

    public Reservation(String number, Timestamp startTime, Timestamp endTime, Boolean paid, StatusType status) {
        this.number = number;
        this.startTime = startTime;
        this.endTime = endTime;
        this.paid = paid;
        this.status = status;
    }
}
