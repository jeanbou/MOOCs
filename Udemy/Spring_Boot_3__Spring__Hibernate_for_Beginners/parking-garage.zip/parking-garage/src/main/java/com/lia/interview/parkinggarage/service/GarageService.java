package com.lia.interview.parkinggarage.service;

import com.lia.interview.parkinggarage.model.Garage;

import java.util.List;

public interface GarageService {
    Garage create(Garage garage);

    Garage update(Garage garage);

    void delete(Long id);

    List<Garage> findAll();

    Garage findGarageById(Long id);

    Garage findByName(String name);
}
