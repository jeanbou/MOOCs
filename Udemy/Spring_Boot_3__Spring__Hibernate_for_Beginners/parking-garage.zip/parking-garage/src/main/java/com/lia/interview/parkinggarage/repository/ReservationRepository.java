package com.lia.interview.parkinggarage.repository;

import com.lia.interview.parkinggarage.model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    Reservation findReservationById(Long id);
//    List<Reservation> getReservationsBy();
}
