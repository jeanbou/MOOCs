package com.lia.interview.parkinggarage.dto;

import com.lia.interview.parkinggarage.model.Reservation;

import javax.persistence.*;
import java.sql.Timestamp;

public class ReservationDTO {
    private String number;
    private Timestamp startTime;
    private Timestamp endTime;
    private Boolean paid;
    private Reservation.StatusType status;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public Boolean getPaid() {
        return paid;
    }

    public void setPaid(Boolean paid) {
        this.paid = paid;
    }

    public Reservation.StatusType getStatus() {
        return status;
    }

    public void setStatus(Reservation.StatusType status) {
        this.status = status;
    }
}
