package com.lia.interview.parkinggarage.model;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity
public class Vehicle {
    @Column(name="id")
    private @Id  @GeneratedValue Long id;
    @Column(name="size")
    private String size;
    @Column(name="plate")
    private String plate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public Vehicle(String size, String plate) {
        this.size = size;
        this.plate = plate;
    }
}
