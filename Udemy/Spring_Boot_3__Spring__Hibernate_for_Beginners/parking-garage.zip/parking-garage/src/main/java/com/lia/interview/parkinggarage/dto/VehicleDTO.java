package com.lia.interview.parkinggarage.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class VehicleDTO {

    @NotNull
    @Min(value = 6)
    private String plateNumber;

    private Long id;

    private String size;

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
