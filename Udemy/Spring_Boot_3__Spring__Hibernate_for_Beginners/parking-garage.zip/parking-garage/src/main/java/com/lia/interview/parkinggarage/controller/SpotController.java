package com.lia.interview.parkinggarage.controller;

import com.lia.interview.parkinggarage.dto.GarageDTO;
import com.lia.interview.parkinggarage.dto.SpotDTO;
import com.lia.interview.parkinggarage.dto.mapper.SpotDTOMapper;
import com.lia.interview.parkinggarage.model.Garage;
import com.lia.interview.parkinggarage.model.Spot;
import com.lia.interview.parkinggarage.service.SpotService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

public class SpotController {
    private final SpotService spotService;
    private final SpotDTOMapper spotMapper;

    public SpotController(SpotService spotService, SpotDTOMapper spotMapper) {
        this.spotService = spotService;
        this.spotMapper = spotMapper;
    }


    @PostMapping()
    public ResponseEntity<SpotDTO> createGarage(@RequestBody SpotDTO spotDTO){
        Spot spot = spotMapper.mapSpotDTOToSpot(spotDTO);
        Spot newSpot = spotService.create(spot);
        return ResponseEntity.ok(spotMapper.mapSpotToSpotDTO(newSpot));
    }

    @PutMapping()
    public ResponseEntity<SpotDTO> update(@RequestBody SpotDTO spotDTO){
        Spot spot = spotMapper.mapSpotDTOToSpot(spotDTO);
        Spot newSpot = spotService.update(spot);
        return ResponseEntity.ok(spotMapper.mapSpotToSpotDTO(newSpot));
    }

//    @GetMapping("/find/{name}")
//    public ResponseEntity<GarageDTO> viewGarageByName(@PathVariable("name") String name){
//        Garage newGarage = garageService.findByName(name);
//        return ResponseEntity.ok(garageMapper.mapGarageToGarageDTO(newGarage));
//    }
//
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<String> createGarage(@PathVariable("id") Long id){
//        garageService.delete(id);
//        return ResponseEntity.ok("Garage Deleted");
//    }
}
