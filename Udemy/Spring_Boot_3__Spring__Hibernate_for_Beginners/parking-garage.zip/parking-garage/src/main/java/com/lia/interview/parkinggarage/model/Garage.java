package com.lia.interview.parkinggarage.model;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.util.Objects;

@Data
@Entity
public class Garage {
    @Column(name="id")
    private @Id @GeneratedValue Long id;
    @Column(name="name", unique = true)
    private String name;
    @Column(name="price_small")
    private BigDecimal priceSmall;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Garage garage = (Garage) o;
        return Objects.equals(id, garage.id) && Objects.equals(name, garage.name) && Objects.equals(priceSmall, garage.priceSmall) && Objects.equals(priceMedium, garage.priceMedium) && Objects.equals(priceLarge, garage.priceLarge);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, priceSmall, priceMedium, priceLarge);
    }

    @Override
    public String toString() {
        return "Garage{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", priceSmall=" + priceSmall +
                ", priceMedium=" + priceMedium +
                ", priceLarge=" + priceLarge +
                '}';
    }

    @Column(name="price_medium")
    private BigDecimal priceMedium;
    @Column(name="price_large")
    private BigDecimal priceLarge;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPriceSmall() {
        return priceSmall;
    }

    public void setPriceSmall(BigDecimal priceSmall) {
        this.priceSmall = priceSmall;
    }

    public BigDecimal getPriceMedium() {
        return priceMedium;
    }

    public void setPriceMedium(BigDecimal priceMedium) {
        this.priceMedium = priceMedium;
    }

    public BigDecimal getPriceLarge() {
        return priceLarge;
    }

    public void setPriceLarge(BigDecimal priceLarge) {
        this.priceLarge = priceLarge;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public Garage(String name, BigDecimal priceSmall, BigDecimal priceMedium, BigDecimal priceLarge) {
        this.name = name;
        this.priceSmall = priceSmall;
        this.priceMedium = priceMedium;
        this.priceLarge = priceLarge;
    }
}
