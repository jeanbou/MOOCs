package com.lia.interview.parkinggarage.view;

public class GarageView {

//    public get
}
